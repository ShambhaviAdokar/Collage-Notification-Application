package com.example.shambhavi.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class create_grp4 extends Activity
{

    String myJSON;

    private static final String TAG_RESULTS="result";
    private static final String TAG_ID = "username";
    ArrayList<HashMap<String, String>>  personList;
    ListView list;
    JSONArray peoples = null;
    String Username;
    public static final String USER_NAME = "USERNAME";
    MyCustomAdapter dataAdapter = null;

    String Class1;
    // public static final String[] Classes ={};

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_grp4);
        Intent intent = getIntent();
        Username = intent.getStringExtra(MainActivity.USER_NAME);
        //Generate list View from ArrayList
        getData();
        checkButtonClick();

    }

    private class MyCustomAdapter extends ArrayAdapter<HashMap<String,String>> {

        ArrayList<HashMap<String, String>> personList;


        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<HashMap<String, String>> personList) {
            super(context, textViewResourceId, personList);
            personList = new ArrayList<HashMap<String, String>>();
            this.personList.addAll(personList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }
    }
       /* @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.country_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        String a=cb.getText().toString();
                        Country country = (Country) cb.getTag();
                        /*Toast.makeText(getApplicationContext(),
                                "Clicked on Checkbox: " + cb.getText() +
                                        " is " + cb.isChecked(),
                                Toast.LENGTH_LONG).show();*/
                       // country.setSelected(cb.isChecked());

                        /*Intent intent;
                        intent = new Intent(create_grp3.this, com.example.shambhavi.myapplication.create_grp3.class);
                        intent.putExtra(Class,a);
                        finish();
                        startActivity(intent);*/



               /* });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            Country country = personList.get(position);
            holder.code.setText(" " +  country.getCode() + "");
            holder.name.setText(country.getName());
            holder.name.setChecked(country.isSelected());
            holder.name.setTag(country);

            return convertView;

        }

    }*/

    private void displayListView()
    {

        //Array list of countries
        list = (ListView) findViewById(R.id.listView);
        personList = new ArrayList<HashMap<String, String>>();

        HashMap<String, String> persons = new HashMap<String, String>();
        //String id = c.getString(TAG_ID);
        //persons.put(TAG_ID,id);
        //personList.add(persons);

        try
        {
            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < peoples.length(); i++)
            {
                JSONObject c = peoples.getJSONObject(i);
                String id = c.getString(TAG_ID);

                HashMap<String, String> person1 = new HashMap<String, String>();
                persons.put(TAG_ID, id);
                //persons.put(TAG_NAME,name);
                // persons.put(TAG_ADD,address);
                personList.add(person1);
            }
            ListAdapter adapter = new SimpleAdapter(
                    create_grp4.this, personList, R.layout.list_item,
                    new String[]{TAG_ID},
                    new int[]{R.id.id});
            list.setAdapter(adapter);
        } catch (JSONException e)
        {
            e.printStackTrace();
        }


        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(create_grp4.this, R.layout.list_item, new create_grp4().personList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id)
            {
                // When clicked, show a toast with the TextView text
                // Country country = (Country) parent.getItemAtPosition(position);
                /*Toast.makeText(getApplicationContext(),
                        "Clicked on Row: " + country.getName(),
                        Toast.LENGTH_LONG).show();*/
            }
        });
    }




    // Button
    private void checkButtonClick()
    {


        Button myButton = (Button) findViewById(R.id.findSelected);
        myButton.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {

                StringBuffer responseText = new StringBuffer();
                responseText.append("The following were selected...\n");
                String[] cls;
                cls = new String[5];
                ArrayList<HashMap<String, String>> personList = dataAdapter.personList;
                int i, j = 0;
               /* for(i=0;i<personList.size();i++)
               {
                    Country country = personList.get(i);
                    if(country.isSelected())
                    {
                        responseText.append("\n" + country.getName());
                        cls[j]=country.getName();

                        j++;
                    }
                }
                Intent intent;
                intent = new Intent(create_grp4.this, com.example.shambhavi.myapplication.example.class);
                intent.putExtra("Classes",cls);
                intent.putExtra("Count",j);
                intent.putExtra(USER_NAME, Username);
                finish();
                startActivity(intent);


        });*/
            }
        });
    }


    public void getData()
    {
        class GetDataJSON extends AsyncTask<String, Void, String>
        {
            @Override
            protected String doInBackground(String... params)
            {
                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://instanotices.site40.net//extractalldata.php");
                // Depends on your web service
                httppost.setHeader("Content-type", "application/json");

                InputStream inputStream = null;
                String result = null;
                try
                {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();
                    inputStream = entity.getContent();
                    // json is UTF-8 by default
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e)
                {
                    // Oops
                } finally
                {
                    try
                    {
                        if (inputStream != null) inputStream.close();
                    } catch (Exception squish)
                    {
                    }
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result)
            {
                myJSON = result;
                displayListView();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }


}

