package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;


public class batches extends Activity {

    MyCustomAdapter dataAdapter = null;

    String selitem,str,str1,prefix;
    Intent intent;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batches);

        displayListView();
        checkButtonClick();
    }

    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","Batch1",false);
        classList.add(c);
        c = new myclass("","Batch2",false);
        classList.add(c);
        c = new myclass("","Batch3",false);
        classList.add(c);
        c = new myclass("","Batch4",false);
        classList.add(c);


        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass country = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText("" +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    str1 = extras.getString("str");
                }


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                }
                else {
                    switch (str1) {
                        case "FE1":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe1b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe1b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe1b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe1b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "FE2":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe2b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe2b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe2b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe2b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "FE3":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe3b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe3b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe3b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe3b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "FE4":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe4b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe4b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe4b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe4b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "FE5":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe5b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe5b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe5b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe5b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "FE6":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe6b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe6b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe6b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe6b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "FE7":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe7b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe7b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe7b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe7b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "FE8":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe8b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe8b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe8b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe8b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "FE9":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe9b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe9b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe9b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe9b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "FE10":
                            switch (selitem)
                            {
                                case "Batch1":
                                    prefix="fe10b1";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix="fe10b2";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix="fe10b3";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix="fe10b4";
                                    intent = new Intent(batches.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                default:
                                    Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                            }

                            break;
                        default:
                            Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                    }
                }


            }
        });

    }


  @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_batches, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
