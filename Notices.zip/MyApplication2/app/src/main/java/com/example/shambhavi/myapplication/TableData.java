package com.example.shambhavi.myapplication;

import android.provider.BaseColumns;

/**
 * Created by Shambhavi on 9/5/2015.
 */
public class TableData {

    public TableData()
    {

    }

    public static abstract class TableInfo implements BaseColumns
    {
        public static final String user_name="user_name";
        public static final String password="password";
        public static final String db_name="Notices1";
        public static final String table_name="login";

    }
}
