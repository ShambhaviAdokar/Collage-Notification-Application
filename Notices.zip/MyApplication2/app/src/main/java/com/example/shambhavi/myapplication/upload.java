package com.example.shambhavi.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;




public class upload extends Activity implements OnClickListener{

    private TextView messageText;
    private Button uploadButton, btnselectpic,done;
    private ImageView imageview;
    private int serverResponseCode = 0;
    private ProgressDialog dialog = null;

    public static String upLoadServerUri = null;
    public static String imagepath=null;
    public String path;

    MyCustomAdapter dataAdapter = null;
    String selitem,str,str1,padding;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        uploadButton = (Button)findViewById(R.id.uploadButton);
        done = (Button)findViewById(R.id.done);
        messageText  = (TextView)findViewById(R.id.messageText);
        btnselectpic = (Button)findViewById(R.id.button_selectpic);
        imageview = (ImageView)findViewById(R.id.imageView_pic);


        btnselectpic.setOnClickListener(this);
        uploadButton.setOnClickListener(this);
        done.setOnClickListener(this);
        upLoadServerUri ="http://instanotices.site40.net//UploadToServer.php";

        //Generate list View from ArrayList
        displayListView();
        //doneButtonClick();
        checkButtonClick();
    }

    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","FE",false);
        classList.add(c);
        c = new myclass("","SE",false);
        classList.add(c);
        c = new myclass("","TE",false);
        classList.add(c);
        c = new myclass("","BE",false);
        classList.add(c);

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass c = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText(" " +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.filter);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }


                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else if (selitem == "FE") {
                    Intent intent = new Intent(upload.this, com.example.shambhavi.myapplication.FE_filter.class);
                    startActivity(intent);
                } else if (selitem == "SE") {
                    Intent intent = new Intent(upload.this, com.example.shambhavi.myapplication.SE_filter.class);
                    startActivity(intent);
                }else if (selitem == "TE") {
                    Intent intent = new Intent(upload.this, com.example.shambhavi.myapplication.TE_filter.class);
                    startActivity(intent);
                }else if (selitem == "BE") {
                    Intent intent = new Intent(upload.this, com.example.shambhavi.myapplication.BE_filter.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                }
            }
        });

    }




    @Override
    public void onClick(View arg0) {

        if(arg0==btnselectpic)
        {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Complete action using"), 1);
        }
        else if (arg0==uploadButton) {

            dialog = ProgressDialog.show(upload.this, "", "Uploading file...", true);
            Bundle extras = getIntent().getExtras();
            ArrayList<myclass> classList = dataAdapter.classList;
            boolean flag=false;
            for (int i = 0; i < classList.size(); i++) {
                myclass c = classList.get(i);
                if (c.isSelected()) {
                    flag = true;
                    break;
                }
            }

            if (extras != null && flag==false ) {
                upLoadServerUri = extras.getString("uri");
                padding=extras.getString("padding");

            }



            Toast.makeText(upload.this,padding , Toast.LENGTH_SHORT).show();
            try {
                new Thread(new Runnable() {
                    public void run() {

                        uploadFile(imagepath);

                    }
                }).start();
            }catch (Exception e)
            {
                Toast.makeText(upload.this, "Oops!Something went wrong...", Toast.LENGTH_SHORT).show();
            }
        }else  if(arg0==done)
        {
            doneButtonClick();
        }
    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1 && resultCode == RESULT_OK) {
            //Bitmap photo = (Bitmap) data.getData().getPath();

            Uri selectedImageUri = data.getData();
            imagepath = getPath(selectedImageUri);
            Bitmap bitmap = BitmapFactory.decodeFile(imagepath);
            imageview.setImageBitmap(bitmap);
            Toast.makeText(upload.this, upLoadServerUri, Toast.LENGTH_SHORT).show();


        }


    }

    public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public int uploadFile(String sourceFileUri) {


        final String fileName = padding+sourceFileUri;
        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;
        final File sourceFile = new File(sourceFileUri);


        if (!sourceFile.isFile()) {

            dialog.dismiss();

            Log.e("uploadFile", "Source File not exist :"+imagepath);

            runOnUiThread(new Runnable() {
                public void run() {
                    messageText.setText("Source File not exist :"+ imagepath);
                }
            });

            return 0;

        }
        else
        {
            try {
                //Toast.makeText(upload.this, upLoadServerUri, Toast.LENGTH_SHORT).show();

                // open a URL connection to the Servlet
                FileInputStream fileInputStream = new FileInputStream(sourceFile);
                URL url = new URL(upLoadServerUri);

                // Open a HTTP  connection to  the URL
                conn = (HttpURLConnection) url.openConnection();

                conn.setDoInput(true); // Allow Inputs
                conn.setDoOutput(true); // Allow Outputs
                conn.setUseCaches(false); // Don't use a Cached Copy
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                conn.setRequestProperty("uploaded_file", fileName);



                dos = new DataOutputStream(conn.getOutputStream());

                dos.writeBytes(twoHyphens + boundary + lineEnd);


                dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
                        + fileName + "\"" + lineEnd);



                ;
                dos.writeBytes(lineEnd);

                // create a buffer of  maximum size
                bytesAvailable = fileInputStream.available();

                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                buffer = new byte[bufferSize];

                // read file and write it into form...
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                while (bytesRead > 0) {

                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                }

                // send multipart form data necesssary after file data...
                dos.writeBytes(lineEnd);
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                // Responses from the server (code and message)
                serverResponseCode = conn.getResponseCode();
                String serverResponseMessage = conn.getResponseMessage();

                Log.i("uploadFile", "HTTP Response is : "
                        + serverResponseMessage + ": " + serverResponseCode);

                if(serverResponseCode == 200){

                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(upload.this, "File Upload Complete.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                //close the streams //
                fileInputStream.close();
                dos.flush();
                dos.close();

            } catch (MalformedURLException ex) {

                dialog.dismiss();
                ex.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        messageText.setText("MalformedURLException Exception : check script url.");
                        Toast.makeText(upload.this, "MalformedURLException", Toast.LENGTH_SHORT).show();
                    }
                });

                Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
            } catch (Exception e) {

                dialog.dismiss();
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        messageText.setText("Got Exception : see logcat ");
                        Toast.makeText(upload.this, "Got Exception : see logcat ", Toast.LENGTH_SHORT).show();
                    }
                });
                //Log.e("Upload file to server Exception", "Exception : "  + e.getMessage(), e);
            }
            dialog.dismiss();
            return serverResponseCode;

        } // End else block
    }


   private void doneButtonClick() {
        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                    switch (selitem) {
                        case "FE":
                            padding = "fe";
                            upLoadServerUri="http://instanotices.site40.net//fe.php";
                            Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
                            break;


                        case "SE":
                            padding = "se";
                            upLoadServerUri="http://instanotices.site40.net//se.php";
                            Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
                            break;

                        case "TE":
                            padding = "te";
                            upLoadServerUri="http://instanotices.site40.net//te.php";
                            Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
                            break;

                        case "BE":
                            padding = "be";
                            upLoadServerUri="http://instanotices.site40.net//be.php";
                            Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
                            break;


                    }
                }
            }

        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_upload, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
            Intent intent = new Intent(upload.this,com.example.shambhavi.myapplication.MainActivity.class);
            finish();
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

