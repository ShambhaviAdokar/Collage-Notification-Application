package com.example.shambhavi.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class batches_te extends AppCompatActivity {

    MyCustomAdapter dataAdapter = null;

    String selitem,str,str1,prefix;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batches_te);

        displayListView();
        checkButtonClick();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_batches_te, menu);
        return true;
    }

    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","Batch1",false);
        classList.add(c);
        c = new myclass("","Batch2",false);
        classList.add(c);
        c = new myclass("","Batch3",false);
        classList.add(c);
        c = new myclass("","Batch4",false);
        classList.add(c);


        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass country = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText("" +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    str1 = extras.getString("str");
                }


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                    switch (str1) {
                        case "TE1":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te1b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te1b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te1b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te1b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "TE2":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te2b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te2b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te2b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te2b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "TE3":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te3b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te3b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te3b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te3b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "TE4":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te4b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te4b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te4b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te4b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fte4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "TE5":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te5b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te5b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te5b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te5b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "TE6":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te6b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te6b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te6b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te6b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "TE7":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te7b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te7b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te7b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te7b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "TE8":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te8b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te8b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te8b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te8b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1te8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "TE9":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te9b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te9b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te9b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te9b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "TE10":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "te10b1";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "te10b2";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "te10b3";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "te10b4";
                                    intent = new Intent(batches_te.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2te10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                default:
                                    Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                            }

                            break;
                        default:
                            Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                    }
                }


            }
        });

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
