package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class OtherAuthority extends AppCompatActivity {

    String Username,auth;

    public static final String USER_NAME = "USERNAME";
    public static final String AUTH = "authority";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_authority);

        Intent intent = getIntent();
        Username = intent.getStringExtra(MainActivity.USER_NAME);
        auth = intent.getStringExtra(MainActivity.AUTH);
        TextView textView = (TextView) findViewById(R.id.textView9);

        textView.setText("Welcome " + Username);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_other_authority, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
            Intent intent = new Intent(OtherAuthority.this,com.example.shambhavi.myapplication.MainActivity.class);
            finish();
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void onbtn_view(View view) {
        Intent intent = new Intent(this, thrid.class);
        startActivity(intent);
    }

    public void onbtn_upload(View view) {
        try{
            Intent intent;
            intent = new Intent(OtherAuthority.this, com.example.shambhavi.myapplication.otherauthupload.class);
            intent.putExtra(USER_NAME,Username);
            intent.putExtra(AUTH,auth);
            startActivity(intent);
        }
        catch(Exception e)
        {
            Toast.makeText(getApplicationContext(),e.toString(), Toast.LENGTH_LONG).show();
        }



    }
}
