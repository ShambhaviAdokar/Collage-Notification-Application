package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class TE_filter extends Activity {

    MyCustomAdapter dataAdapter = null;
    String selitem,str,str1,prefix;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_te_filter);

        //Generate list View from ArrayList
        displayListView();
        doneButtonClick();
        checkButtonClick();
    }

    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","TE1",false);
        classList.add(c);
        c = new myclass("","TE2",false);
        classList.add(c);
        c = new myclass("","TE3",false);
        classList.add(c);
        c = new myclass("","TE4",false);
        classList.add(c);
        c = new myclass("","TE5",false);
        classList.add(c);
        c = new myclass("","TE6",false);
        classList.add(c);
        c = new myclass("","TE7",false);
        classList.add(c);
        c = new myclass("","TE8",false);
        classList.add(c);
        c = new myclass("","TE9",false);
        classList.add(c);
        c = new myclass("","TE10",false);
        classList.add(c);

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass country = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText("" +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.filter);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                }  else {
                    switch (selitem) {
                        case "TE1":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE1";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE2":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE2";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE3":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE3";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE4":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE4";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE5":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE5";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE6":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE6";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE7":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE7";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE8":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE8";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE9":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE9";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                        case "TE10":
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.batches_te.class);
                            str = "TE10";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                    }
                     }
                }
        });

    }

    private void doneButtonClick() {
        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                    switch (selitem) {
                        case "TE1":
                            prefix="te1";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//fte1.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;


                        case "TE2":
                            prefix="te2";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//fte2.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE3":
                            prefix="te3";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//fte3.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE4":
                            prefix="te4";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//fte4.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE5":
                            prefix="te5";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f1te5.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE6":
                            prefix="te6";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f1te6.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE7":
                            prefix="te7";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f1te7.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE8":
                            prefix="te8";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f1te8.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE9":
                            prefix="se9";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f2te9.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "TE10":
                            prefix="te10";
                            intent = new Intent(TE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f2te10.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;

                    }
                }
            }

        });


    }

   @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_te_filter, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
