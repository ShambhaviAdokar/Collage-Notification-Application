package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;


public class example extends ActionBarActivity {
 String myJSON;

 private static final String TAG_RESULTS="result";
 private static final String TAG_ID = "username";
    public static final String FINAL_GRP= "final_grp";
    public static final String count= "count";
 JSONArray peoples = null;
    public static final String USER_NAME = "USERNAME";
  ArrayList<HashMap<String, String>> personList;
  ListView list;
    int i,j,k=0,p,z=0;
    String[] Class1;
    String Username;
    EditText etx;
    String[] final_mem;
    String[] cls;
    String a;
    int cl;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  setContentView(R.layout.activity_example);
      Intent intent = getIntent();
      Class1 = intent.getStringArrayExtra("Classes");
      j = intent.getIntExtra("Count",0);
      cls=new String[5];

      for(int i=0;i<j;i++)
      {
          a=Class1[i];
          switch(a)
          {

              //FE
              case "FE1": cls[i]="11";break;
              case "FE2": cls[i]="12";break;
              case "FE3": cls[i]="13";break;
              case "FE4": cls[i]="14";break;
              case "FE5": cls[i]="15";break;
              case "FE6": cls[i]="16";break;
              case "FE7": cls[i]="17";break;
              case "FE8": cls[i]="18";break;
              case "FE9": cls[i]="19";break;
              case "FE10": cls[i]="10";break;

              //SE

              case "SE1": cls[i]="21";break;
              case "SE2": cls[i]="22";break;
              case "SE3": cls[i]="23";break;
              case "SE4": cls[i]="24";break;
              case "SE5": cls[i]="25";break;
              case "SE6": cls[i]="26";break;
              case "SE7": cls[i]="27";break;
              case "SE8": cls[i]="28";break;
              case "SE9": cls[i]="29";break;
              case "SE10": cls[i]="20";break;

              //TE
              case "TE1": cls[i]="31";break;
              case "TE2": cls[i]="32";break;
              case "TE3": cls[i]="33";break;
              case "TE4": cls[i]="34";break;
              case "TE5": cls[i]="35";break;
              case "TE6": cls[i]="36";break;
              case "TE7": cls[i]="37";break;
              case "TE8": cls[i]="38";break;
              case "TE9": cls[i]="39";break;
              case "TE10": cls[i]="30";break;


              //BE
              case "BE1": cls[i]="41";break;
              case "BE2": cls[i]="42";break;
              case "BE3": cls[i]="43";break;
              case "BE4": cls[i]="44";break;
              case "BE5": cls[i]="45";break;
              case "BE6": cls[i]="46";break;
              case "BE7": cls[i]="47";break;
              case "BE8": cls[i]="48";break;
              case "BE9": cls[i]="49";break;
              case "BE10": cls[i]="40";break;


          }
      }
     /*for(int i=0;i<j;i++)
          Toast.makeText(getApplicationContext(), Class1[i], Toast.LENGTH_LONG).show();*/
      final_mem=new String[20];
      etx=(EditText)findViewById(R.id.editText5);

      Username = intent.getStringExtra(create_grp3.USER_NAME);
      //Toast.makeText(getApplicationContext(), Username, Toast.LENGTH_LONG).show();
      list = (ListView) findViewById(R.id.listView);
        personList = new ArrayList<HashMap<String,String>>();
        getData();
        }


protected void showList(){
      try {
           JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);
            int flag=0;
            for(int i =0;i<peoples.length();i++)
            {
            JSONObject c = peoples.getJSONObject(i);
            String id = c.getString(TAG_ID);
            String id_sub=id.substring(0,2);
                for(p=0;p<j;p++)
                {
                    if(cls[p].equals(id_sub)) {
                        flag = 1;
                        HashMap<String,String> persons = new HashMap<String,String>();
                        persons.put(TAG_ID,id);
                        personList.add(persons);
                        break;
                    }
                }

                }
            ListAdapter adapter = new SimpleAdapter(
            example.this, personList, R.layout.list_item,
            new String[]{TAG_ID},
                    new int[]{R.id.id}
           );
            list.setAdapter(adapter);
            } catch (JSONException e) {
            e.printStackTrace();
            }

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id) {
            z=k;
            // When clicked, show a toast with the TextView text
            try {
                String s =  (list.getItemAtPosition(position)).toString();
                String mstr=s.substring(10,14);
                etx.append(" "+mstr);
                final_mem[k]=mstr;
                k++;

            }catch(Exception e)
            {
                Toast.makeText(getApplicationContext(),e.toString(),
                        Toast.LENGTH_SHORT).show();
            }
            finally {

              //  Toast.makeText(getApplicationContext(), final_mem[z] ,Toast.LENGTH_SHORT).show();
            }
        }
    });

        }
    public void getData()
    {
        class GetDataJSON extends AsyncTask<String, Void, String>{
         @Override
         protected String doInBackground(String... params)
         {
             DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
             HttpPost httppost = new HttpPost("http://instanotices.site40.net//extractalldata.php");
                 // Depends on your web service
             httppost.setHeader("Content-type", "application/json");

            InputStream inputStream = null;
            String result = null;
            try {
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                inputStream = entity.getContent();
                // json is UTF-8 by default
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
             while ((line = reader.readLine()) != null)
             {
                 sb.append(line + "\n");
             }
             result = sb.toString();
             } catch (Exception e)
            {
            // Oops
            }
            finally
            {
                 try{if(inputStream != null)inputStream.close();}catch(Exception squish){}
             }
            return result;
         }
      @Override
        protected void onPostExecute(String result)
         {
          myJSON = result;
          showList();
         }
        }
       GetDataJSON g = new GetDataJSON();
       g.execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.menu_example, menu);
    return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    int id = item.getItemId();
    //noinspection SimplifiableIfStatement
    if (id == R.id.action_done) {
        z++;
        final_mem[z]="Stop";
       // Toast.makeText(getApplicationContext(), final_mem[z] ,Toast.LENGTH_SHORT).show();
        Intent intent;
        intent = new Intent(example.this, com.example.shambhavi.myapplication.create_group.class);
        intent.putExtra(FINAL_GRP,final_mem);
        intent.putExtra(count,z);
        intent.putExtra(USER_NAME, Username);
        finish();
        startActivity(intent);
    return true;
    }
    return super.onOptionsItemSelected(item);
    }
}