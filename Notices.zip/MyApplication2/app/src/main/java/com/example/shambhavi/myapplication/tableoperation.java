package com.example.shambhavi.myapplication;
import android.app.ActionBar;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Shambhavi on 9/5/2015.
 */
public class tableoperation extends SQLiteOpenHelper {

    public String create_query="Create table "+ TableData.TableInfo.table_name+"("+ TableData.TableInfo.user_name+" TEXT , "+ TableData.TableInfo.password+" TEXT );";
    public static final int database_version=1;
    public tableoperation(Context context)
    {
    super(context, TableData.TableInfo.db_name,null,database_version);
        Log.d("table operations","database created successfully");
    }


    @Override
    public void onCreate(SQLiteDatabase dbs)
    {
    dbs.execSQL(create_query);
        Log.d("table operations", "table created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbs,int agr1,int agr2)
    {

    }

    public void put_info(tableoperation tops,String name,String pass)
    {
        SQLiteDatabase SQ= tops.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(TableData.TableInfo.user_name,name);
        cv.put(TableData.TableInfo.password, pass);
        long k=SQ.insert(TableData.TableInfo.table_name,null,cv);
        Log.d("tableoperations","One Row inserted");

    }


}
