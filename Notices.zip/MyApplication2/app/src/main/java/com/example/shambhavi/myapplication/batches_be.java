package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
public class batches_be extends AppCompatActivity {

    MyCustomAdapter dataAdapter = null;

    String selitem,str,str1,prefix;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batches_be);

        displayListView();
        checkButtonClick();
    }


    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","Batch1",false);
        classList.add(c);
        c = new myclass("","Batch2",false);
        classList.add(c);
        c = new myclass("","Batch3",false);
        classList.add(c);
        c = new myclass("","Batch4",false);
        classList.add(c);


        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass country = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText("" +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    str1 = extras.getString("str");
                }


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                    switch (str1) {
                        case "BE1":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be1b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be1b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be1b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be1b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe1.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "BE2":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be2b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be2b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be2b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be2b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe2.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "BE3":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be3b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be3b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be3b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be3b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe3.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "BE4":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be4b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be4b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be4b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be4b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//fbe4.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "BE5":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be5b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be5b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be5b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be5b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be5.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;


                        case "BE6":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be6b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be6b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be6b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be6b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be6.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "BE7":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be7b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be7b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be7b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be7b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be7.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "BE8":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be8b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be8b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be8b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be8b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f1be8.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "BE9":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be9b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be9b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be9b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be9b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be9.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                            }

                            break;

                        case "BE10":
                            switch (selitem) {
                                case "Batch1":
                                    prefix = "be10b1";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch2":
                                    prefix = "be10b2";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch3":
                                    prefix = "be10b3";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                case "Batch4":
                                    prefix = "be10b4";
                                    intent = new Intent(batches_be.this, com.example.shambhavi.myapplication.upload.class);
                                    str = "http://instanotices.site40.net//f2be10.php";
                                    intent.putExtra("uri", str);
                                    intent.putExtra("padding", prefix);
                                    startActivity(intent);
                                    break;
                                default:
                                    Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                            }

                            break;
                        default:
                            Toast.makeText(getApplicationContext(), "OOPs!!", Toast.LENGTH_LONG).show();

                    }
                }


            }
        });

    }


   @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_batches_be, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
