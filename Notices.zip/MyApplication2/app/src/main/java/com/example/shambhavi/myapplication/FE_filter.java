package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import org.apache.http.client.methods.HttpPost;

public class FE_filter extends Activity {

    MyCustomAdapter dataAdapter = null;
    String selitem,str,str1,prefix;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fe_filter);

        //Generate list View from ArrayList
        displayListView();
        doneButtonClick();
        checkButtonClick();

    }

    private void displayListView() {

        //Array list of classes
        ArrayList<myclass> classList = new ArrayList<myclass>();
        myclass c = new myclass("","FE1",false);
        classList.add(c);
        c = new myclass("","FE2",false);
        classList.add(c);
        c = new myclass("","FE3",false);
        classList.add(c);
        c = new myclass("","FE4",false);
        classList.add(c);
        c = new myclass("","FE5",false);
        classList.add(c);
        c = new myclass("","FE6",false);
        classList.add(c);
        c = new myclass("","FE7",false);
        classList.add(c);
        c = new myclass("","FE8",false);
        classList.add(c);
        c = new myclass("","FE9",false);
        classList.add(c);
        c = new myclass("","FE10",false);
        classList.add(c);

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.myclass_info, classList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                myclass country = (myclass) parent.getItemAtPosition(position);

            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<myclass> {

        private ArrayList<myclass> classList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<myclass> classList) {
            super(context, textViewResourceId, classList);
            this.classList = new ArrayList<myclass>();
            this.classList.addAll(classList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.myclass_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        myclass c = (myclass) cb.getTag();
                        selitem=cb.getText().toString();
                        c.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            myclass c = classList.get(position);
            holder.code.setText("" +  c.getCode() + "");
            holder.name.setText(c.getName());
            holder.name.setChecked(c.isSelected());
            holder.name.setTag(c);

            return convertView;

        }

    }

    private void checkButtonClick() {
        Button myButton = (Button) findViewById(R.id.filter);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                     switch (selitem) {
                        case "FE1":
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                            str="FE1";
                            intent.putExtra("str", str);
                            startActivity(intent);
                            break;
                         case "FE2":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE2";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE3":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE3";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE4":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE4";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE5":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE5";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE6":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE6";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE7":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE7";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE8":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE8";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE9":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE9";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;
                         case "FE10":
                             intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.batches.class);
                             str="FE10";
                             intent.putExtra("str", str);
                             startActivity(intent);
                             break;

                    }
                }
            }
        });}



    private void doneButtonClick() {
        Button myButton = (Button) findViewById(R.id.done);
        myButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {


                int j = 0;
                StringBuffer responseText = new StringBuffer();
                ArrayList<myclass> classList = dataAdapter.classList;
                for (int i = 0; i < classList.size(); i++) {
                    myclass c = classList.get(i);
                    if (c.isSelected()) {
                        responseText.append("\n" + c.getName());
                        selitem = c.getName();
                        j++;
                    }
                }

                if (j > 1 || j == 0) {
                    Toast.makeText(getApplicationContext(), "Select Exactly one class", Toast.LENGTH_LONG).show();
                } else {
                    switch (selitem) {
                        case "FE1":
                            prefix="fe1";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f1.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;


                        case "FE2":
                            prefix="fe2";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f2.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE3":
                            prefix="fe3";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f3.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE4":
                            prefix="fe4";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f4.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE5":
                            prefix="fe5";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f5.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE6":
                            prefix="fe6";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f6.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE7":
                            prefix="fe7";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f7.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE8":
                            prefix="fe8";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f8.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE9":
                            prefix="fe9";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f9.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;
                        case "FE10":
                            prefix="fe10";
                            intent = new Intent(FE_filter.this, com.example.shambhavi.myapplication.upload.class);
                            str = "http://instanotices.site40.net//f10.php";;
                            intent.putExtra("uri", str);
                            intent.putExtra("padding", prefix);
                            startActivity(intent);
                            break;

                    }
                }
            }

        });


    }







   @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_fe_filter, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
