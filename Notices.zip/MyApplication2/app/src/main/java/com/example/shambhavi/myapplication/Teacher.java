package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Teacher extends AppCompatActivity {

    String Username;
    public static final String USER_NAME = "USERNAME";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        Intent intent = getIntent();
        Username = intent.getStringExtra(MainActivity.USER_NAME);

        TextView textView = (TextView) findViewById(R.id.textView4);

        textView.setText("Welcome " + Username);



        getMenuInflater().inflate(R.menu.menu_teacher, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
            Intent intent = new Intent(Teacher.this,com.example.shambhavi.myapplication.MainActivity.class);
            finish();
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onbtn_view(View view) {
        Intent intent = new Intent(this, thrid.class);
        startActivity(intent);
    }

    public void onbtn_upload(View view) {
        Intent intent = new Intent(this, upload.class);
        startActivity(intent);

    }

    public void oncreate(View view) {
        Intent intent = new Intent(this, create_group.class);
        intent.putExtra(USER_NAME, Username);
        startActivity(intent);

    }

    public void btn_mygrp(View view) {
        Intent intent = new Intent(this, student_activity.class);
        Toast.makeText(getApplicationContext(), Username, Toast.LENGTH_LONG).show();
        intent.putExtra(USER_NAME, Username);
        startActivity(intent);

    }


}
