package com.example.shambhavi.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class create_group extends AppCompatActivity {

    String[] stud = null;
    String grp_name;
    Button add_btn1;
    Button creat_grp;
    EditText etxt1, etxt2,etxt3;
    public static final String USER_NAME = "USERNAME";
    int i = 0,flag=0,count;
    String Username,Username1;
    String[] finalgrp;
    String j;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finalgrp=new String[20];
        j=new String();
        j="0";
        stud = new String[20];
        intent = getIntent();
        Username1=new String();
        finalgrp= intent.getStringArrayExtra(example.FINAL_GRP);
        Username1 = intent.getStringExtra(example.USER_NAME);
      //  Toast.makeText(getApplicationContext(),Username1, Toast.LENGTH_LONG).show();
        j= intent.getStringExtra(example.count);
        Username = intent.getStringExtra(MainActivity.USER_NAME);

        setContentView(R.layout.activity_create_group);
        add_btn1 = (Button) findViewById(R.id.button5);
        creat_grp = (Button) findViewById(R.id.button3);
        etxt1 = (EditText) findViewById(R.id.editText4);
        etxt2 = (EditText) findViewById(R.id.editText2);
        etxt3=(EditText) findViewById(R.id.editText3);




        add_grpmembers();
    }

    void add_grpmembers()
    {
        try
        {
            i=0;
            etxt2.setText(finalgrp[0]);

            i=1;
            while(!finalgrp[i].equals("Stop"))
            {

                etxt2.append("\n" + finalgrp[i]);
                i++;
                flag=1;

            }
           count=i;
        }
        catch(Exception e)
        {
           // Toast.makeText(getApplicationContext(),e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_create_group, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void create_grp_btn(View view) {
        //login(stud);
        if(flag==0) {
            stud[i] = "Stop";
            count=i;
        }
        String usr=etxt3.getText().toString();
        if(usr.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please Enter the group name", Toast.LENGTH_LONG).show();
        }
        else {
            grp_name = etxt3.getText().toString();


        if(flag==1) {

            Username1 = intent.getStringExtra(create_grp3.USER_NAME);
            grp_name = Username1 + grp_name;
            etxt3.setText(grp_name);
            stud=finalgrp;
            insertToDatabase();
        }
        else
        {

            grp_name = Username + grp_name;
            etxt3.setText(grp_name);
            insertToDatabase();
        }

        }
    }

    public void add_btn(View view) {

        stud[i] = etxt1.getText().toString();
        etxt1.setText("");
        etxt2.append(stud[i] + "\n");
        i++;
    }

    public void view(View view) {

        Intent intent;
        intent = new Intent(create_group.this, com.example.shambhavi.myapplication.create_grp2.class);
        intent.putExtra(USER_NAME, Username);
        startActivity(intent);

    }

    private void insertToDatabase() {
        i = 0;
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {


                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                while (i<count) {

                    nameValuePairs.add(new BasicNameValuePair("stud_id", stud[i]));
                    nameValuePairs.add(new BasicNameValuePair("grp_id", grp_name));


                    try {
                        HttpClient httpClient = new DefaultHttpClient();
                        HttpPost httpPost = new HttpPost("http://instanotices.site40.net//creategrp.php");
                        httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                        HttpResponse response = httpClient.execute(httpPost);
                        HttpEntity entity = response.getEntity();
                    } catch (ClientProtocolException e) {
                    } catch (IOException e) {
                    }
                    i++;
                }

                nameValuePairs.add(new BasicNameValuePair("grp_id", grp_name));
                nameValuePairs.add(new BasicNameValuePair("teacher_id", Username));

                try {
                    HttpClient httpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost("http://instanotices.site40.net//creategrp1.php");
                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpClient.execute(httpPost);
                    HttpEntity entity = response.getEntity();
                } catch (ClientProtocolException e) {
                } catch (IOException e) {
                }
                return "success";

            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
                Toast.makeText(getApplicationContext(), "Group Created", Toast.LENGTH_LONG).show();
            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute(stud);
    }
}




