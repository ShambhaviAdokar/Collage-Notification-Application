package com.example.shambhavi.myapplication;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class create_grp3 extends Activity {

    String Username;
    public static final String USER_NAME = "USERNAME";
    MyCustomAdapter dataAdapter = null;

    String Class1;
   // public static final String[] Classes ={};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_grp3);

        Intent intent = getIntent();
        Class1 = intent.getStringExtra(create_grp2.Class);


        Username = intent.getStringExtra(create_grp2.USER_NAME);
       // Toast.makeText(getApplicationContext(), Username, Toast.LENGTH_LONG).show();

        //Generate list View from ArrayList
        displayListView();

        checkButtonClick();

    }

    private void displayListView() {

        //Array list of countries
        ArrayList<Country> countryList = new ArrayList<Country>();

        if(Class1.equals("FE")) {



            Country country = new Country("Comp", "FE1", false);
            countryList.add(country);
            country = new Country("Comp", "FE2", false);
            countryList.add(country);
            country = new Country("Comp", "FE3", false);
            countryList.add(country);
            country = new Country("Comp", "FE4", false);
            countryList.add(country);
            country = new Country("ENTC", "FE5", false);
            countryList.add(country);
            country = new Country("Entc", "FE6", false);
            countryList.add(country);
            country = new Country("ENTC", "FE7", false);
            countryList.add(country);
            country = new Country("ENTC", "FE8", false);
            countryList.add(country);


            country = new Country("IT", "FE9", false);
            countryList.add(country);
            country = new Country("IT", "FE10", false);
            countryList.add(country);


        }

        if(Class1.equals("SE")) {
            if(Username.charAt(0)=='C') {

                Country country = new Country("", "SE1", false);
                countryList.add(country);
                country = new Country("", "SE2", false);
                countryList.add(country);
                country = new Country("", "SE3", false);
                countryList.add(country);
                country = new Country("", "SE4", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='E') {

                Country country = new Country("", "SE5", false);
                countryList.add(country);
                country = new Country("", "SE6", false);
                countryList.add(country);
                country = new Country("", "SE7", false);
                countryList.add(country);
                country = new Country("", "SE8", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='I') {
                Country country = new Country("", "SE9", false);
                countryList.add(country);
                country = new Country("", "SE10", false);
                countryList.add(country);
            }
        }

        if(Class1.equals("TE")) {

            if(Username.charAt(0)=='C') {
                Country country = new Country("", "TE1", false);
                countryList.add(country);
                country = new Country("", "TE2", false);
                countryList.add(country);
                country = new Country("", "TE3", false);
                countryList.add(country);
                country = new Country("", "TE4", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='E') {
                Country country = new Country("", "TE5", false);
                countryList.add(country);
                country = new Country("", "TE6", false);
                countryList.add(country);
                country = new Country("", "TE7", false);
                countryList.add(country);
                country = new Country("", "TE8", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='I') {
                Country country = new Country("", "TE9", false);
                countryList.add(country);
                country = new Country("", "TE10", false);
                countryList.add(country);
            }
        }

        if(Class1.equals("BE")) {

            if(Username.charAt(0)=='C') {
                Country country = new Country("", "BE1", false);
                countryList.add(country);
                country = new Country("", "BE2", false);
                countryList.add(country);
                country = new Country("", "BE3", false);
                countryList.add(country);
                country = new Country("", "BE4", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='C') {
                Country country = new Country("", "BE5", false);
                countryList.add(country);
                country = new Country("", "BE6", false);
                countryList.add(country);
                country = new Country("", "BE7", false);
                countryList.add(country);
                country = new Country("", "BE8", false);
                countryList.add(country);
            }
            if(Username.charAt(0)=='I') {
                Country country = new Country("", "BE9", false);
                countryList.add(country);
                country = new Country("", "BE10", false);
                countryList.add(country);
            }
        }






        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.country_info, countryList);
        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                Country country = (Country) parent.getItemAtPosition(position);
                /*Toast.makeText(getApplicationContext(),
                        "Clicked on Row: " + country.getName(),
                        Toast.LENGTH_LONG).show();*/
            }
        });

    }

    private class MyCustomAdapter extends ArrayAdapter<Country> {

        private ArrayList<Country> countryList;

        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<Country> countryList) {
            super(context, textViewResourceId, countryList);
            this.countryList = new ArrayList<Country>();
            this.countryList.addAll(countryList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.country_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        String a=cb.getText().toString();
                        Country country = (Country) cb.getTag();
                        /*Toast.makeText(getApplicationContext(),
                                "Clicked on Checkbox: " + cb.getText() +
                                        " is " + cb.isChecked(),
                                Toast.LENGTH_LONG).show();*/
                        country.setSelected(cb.isChecked());

                        /*Intent intent;
                        intent = new Intent(create_grp3.this, com.example.shambhavi.myapplication.create_grp3.class);
                        intent.putExtra(Class,a);
                        finish();
                        startActivity(intent);*/


                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            Country country = countryList.get(position);
            holder.code.setText(" " +  country.getCode() + "");
            holder.name.setText(country.getName());
            holder.name.setChecked(country.isSelected());
            holder.name.setTag(country);

            return convertView;

        }

    }


    // Button
    private void checkButtonClick() {


        Button myButton = (Button) findViewById(R.id.findSelected);
        myButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                StringBuffer responseText = new StringBuffer();
                responseText.append("The following were selected...\n");
                String[] cls;
                cls=new String[5];
                ArrayList<Country> countryList = dataAdapter.countryList;
                int i,j=0;
                for(i=0;i<countryList.size();i++){
                    Country country = countryList.get(i);
                    if(country.isSelected()){
                        responseText.append("\n" + country.getName());
                      cls[j]=country.getName();

                        j++;
                    }
                }


               //Toast.makeText(getApplicationContext(),
                // responseText, Toast.LENGTH_LONG).show();


                        Intent intent;
                intent = new Intent(create_grp3.this, com.example.shambhavi.myapplication.example.class);
                intent.putExtra("Classes",cls);
                intent.putExtra("Count",j);
                intent.putExtra(USER_NAME, Username);
                finish();
                startActivity(intent);

            }
        });

    }

}