package com.example.shambhavi.myapplication;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;



public class MainActivity extends ActionBarActivity {

    private EditText editTextUserName;
    private EditText editTextPassword;

    String Authority,auth;
    public static final String AUTH = "AUTHORITY";
    public static final String USER_NAME = "USERNAME";

    String Username;
    String Password;
    Spinner s;
    HttpPost httpPost ;
    String choice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUserName = (EditText) findViewById(R.id.editTextusr);
        editTextPassword = (EditText) findViewById(R.id.editTextpwd);
        s = (Spinner) findViewById(R.id.static_spinner);

        final ArrayList<String> list = new ArrayList<String>();   //make this as field atribute
        list.add("Student");
        list.add("Teacher");
        list.add("TNP Head");
        list.add("Student Section Cordinator");
        list.add("Librarian");
        list.add("IEEE Head");
        list.add("Pictorial Head");
        list.add("ACM Head");
        list.add("IET Head");
        list.add("Art Circle Head");
        list.add("INC Head");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        s.setAdapter(adapter);

        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                //list.get(position);

                s.setSelection(position);
                Authority= (String) s.getSelectedItem();
                try {
                    switch (Authority) {
                        case "Student":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student.php");
                            auth="Student";
                            //Toast.makeText(getApplicationContext(), selState, Toast.LENGTH_LONG).show();
                            break;
                        case "Teacher":
                            httpPost = new HttpPost("http://instanotices.site40.net//Teacher.php");
                            auth="Teacher";
                            break;
                        case "TNP Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Teacher_head.php");
                            auth="TNP";
                            break;
                        case "Librarian":
                            httpPost = new HttpPost("http://instanotices.site40.net//Teacher_head.php");
                            auth="Library";
                            break;
                        case "Student Section Coordinator":
                            httpPost = new HttpPost("http://instanotices.site40.net//Teacher_head.php");
                            auth="Student_section";
                            break;
                        case "Art Circle Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student_head.php");
                            auth="Art_circle";
                            break;
                        case "ACM Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student_head.php");
                            auth="ACM";
                            break;
                        case "Pictorial Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student_head.php");
                            auth="Pictorial";
                            break;
                        case "IET Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student_head.php");
                            auth="IET";
                            break;
                        case "INC Head":
                            httpPost = new HttpPost("http://instanotices.site40.net//Student_head.php");
                            auth="INC";
                            break;

                    }
                }

                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });







    }

    public void invokeLogin(View view) {

        choice= (String) s.getSelectedItem();

        Username = editTextUserName.getText().toString();
        Password = editTextPassword.getText().toString();
        if (Username.equals("") || Password.equals(""))
            Toast.makeText(getApplicationContext(), "Please Enter the Data", Toast.LENGTH_LONG).show();
        else
            login(Username, Password);

    }

    private void login(final String Username, final String Password) {

        class LoginAsync extends AsyncTask<String, Void, String> {

            private Dialog loadingDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loadingDialog = ProgressDialog.show(MainActivity.this, "Please wait", "Loading...");
            }

            @Override
            protected String doInBackground(String... params) {
                String uname = params[0];
                String pass = params[1];

                InputStream is = null;
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                nameValuePairs.add(new BasicNameValuePair("Username", uname));
                nameValuePairs.add(new BasicNameValuePair("Password", pass));
                nameValuePairs.add(new BasicNameValuePair("Authority",auth));

                String result = null;

                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();

                    is = entity.getContent();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return result;

            }

            @Override
            protected void onPostExecute(String result) {
                try {
                    String s = result.trim();
                    String mystr[] = s.split(" ", 4);
                    String mstr = mystr[0];
                    // Toast.makeText(getApplicationContext(), mstr, Toast.LENGTH_LONG).show();
                    loadingDialog.dismiss();

                    if (mstr.equalsIgnoreCase("Success") || mstr.equalsIgnoreCase("Success\n<!--")) {
                        Intent intent;
                        if (Authority.equals("Student")) {
                            intent = new Intent(MainActivity.this, com.example.shambhavi.myapplication.second.class);
                            intent.putExtra(USER_NAME, Username);
                            finish();
                            startActivity(intent);
                        } else if (Authority.equals("Teacher")) {
                            intent = new Intent(MainActivity.this, com.example.shambhavi.myapplication.Teacher.class);
                            intent.putExtra(USER_NAME, Username);
                            finish();
                            startActivity(intent);

                        } else {

                            intent = new Intent(MainActivity.this, com.example.shambhavi.myapplication.OtherAuthority.class);
                            intent.putExtra(USER_NAME, Username);
                            intent.putExtra(AUTH,choice);
                            finish();
                            startActivity(intent);
                        }


                    } else {
                        editTextPassword.setText("");
                        editTextUserName.setText("");
                        Toast.makeText(getApplicationContext(), "Invalid User Name or Password", Toast.LENGTH_LONG).show();

                    }
                } catch(Exception e)
                {
                    Toast.makeText(getApplicationContext(), "Check Your Internet Connection", Toast.LENGTH_LONG).show();
                }
            }

        }

        LoginAsync la = new LoginAsync();
        la.execute(Username, Password);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_About) {
            Intent intent;
            intent = new Intent(MainActivity.this, com.example.shambhavi.myapplication.About.class);
            startActivity(intent);

            return true;
        }
            return super.onOptionsItemSelected(item);

    }

    public void onView(View view)
    {
        Intent intent;
        intent = new Intent(MainActivity.this, com.example.shambhavi.myapplication.example2.class);
        startActivity(intent);
    }
}

